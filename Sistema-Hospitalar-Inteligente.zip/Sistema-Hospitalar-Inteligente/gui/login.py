import customtkinter as ctg
from tkinter import messagebox
from database.conexao import SessionLocal
from core.servicos import UtilizadorServico
from gui.dashboard import JanelaDashboard

ctg.set_appearance_mode("Dark")  
ctg.set_default_color_theme("blue") 

class TelaLogin(ctg.CTk):
    def __init__(self):
        super().__init__()
        self.title("Sistema Hospitalar Inteligente")
        self.geometry("480x500")
        self.resizable(False, False)
        self.configure(fg_color="#0F172A") 

        self.card_login = ctg.CTkFrame(self, width=400, height=440, corner_radius=20, fg_color="#1E293B", border_width=2, border_color="#334155")
        self.card_login.place(relx=0.5, rely=0.5, anchor="center")

        self.label_icon = ctg.CTkLabel(self.card_login, text="🏥", font=("Arial", 45))
        self.label_icon.pack(pady=(30, 5))

        self.label_titulo = ctg.CTkLabel(self.card_login, text="MED-AI PANEL", font=("Segoe UI", 24, "bold"), text_color="#38BDF8")
        self.label_titulo.pack(pady=(0, 5))
        
        self.label_subtitulo = ctg.CTkLabel(self.card_login, text="Introduza as suas credenciais de acesso", font=("Segoe UI", 12), text_color="#94A3B8")
        self.label_subtitulo.pack(pady=(0, 25))

        self.input_user = ctg.CTkEntry(self.card_login, placeholder_text="Nome de utilizador", width=320, height=45, corner_radius=10, fg_color="#0F172A", text_color="#F8FAFC", placeholder_text_color="#64748B", border_color="#475569", border_width=1)
        self.input_user.pack(pady=10)

        self.input_pass = ctg.CTkEntry(self.card_login, placeholder_text="Palavra-passe", show="*", width=320, height=45, corner_radius=10, fg_color="#0F172A", text_color="#F8FAFC", placeholder_text_color="#64748B", border_color="#475569", border_width=1)
        self.input_pass.pack(pady=10)

        # O comando chama self.executar_login
        self.btn_login = ctg.CTkButton(self.card_login, text="AUTENTICAR", command=self.executar_login, width=320, height=45, corner_radius=10, font=("Segoe UI", 14, "bold"), fg_color="#0284C7", hover_color="#0369A1", text_color="#FFFFFF")
        self.btn_login.pack(pady=(30, 20))

    
    def executar_login(self):
        usuario = self.input_user.get()
        senha = self.input_pass.get()

        if not usuario or not senha:
            messagebox.showwarning("Aviso", "Preencha todos os campos obrigatórios!")
            return

        db = SessionLocal()
        servico = UtilizadorServico(db)
        
        try:
            utilizador = servico.autenticar(usuario, senha)
            messagebox.showinfo("Sucesso", f"Bem-vindo, {utilizador.username}!\nFunção: {utilizador.funcao}")
            
            username_logado = utilizador.username
            funcao_logada = utilizador.funcao
            
            self.destroy() 
            
            painel = JanelaDashboard(username=username_logado, funcao=funcao_logada)
            painel.mainloop()
            
        except Exception as e:
            messagebox.showerror("Erro de Autenticação", str(e))
        finally:
            db.close()

if __name__ == "__main__":
    app = TelaLogin()
    app.mainloop()